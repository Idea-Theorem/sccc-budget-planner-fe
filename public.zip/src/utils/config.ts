// const testnetConfig = {
//   Base_URL: "http://localhost:5000/api",

// };
const mainnetConfig = {
  Base_URL: "http://20.151.79.66/api",
};

const defaultConfig = mainnetConfig;

export default defaultConfig;
