export const departments=[
    {title: 'Recreation & Culture', color: 'rgba(98, 0, 238, 1)'},
    {title: 'Health & Wellness', color: 'rgba(38, 166, 154, 1)'},
    {title: 'Finance', color: 'rgba(238, 96, 2, 1)'},
    {title: 'Human Resources', color: 'rgba(255, 193, 7, 1)'},
    {title: 'Events & Community', color: 'rgba(7, 195, 255, 1)'},
    {title: 'Department 3', color: 'rgba(7, 62, 255, 1)'},
    {title: 'Department 6', color: 'rgba(38, 166, 154, 1)'},
    {title: 'Department 8', color: 'rgba(238, 96, 2, 1)'},
    {title: 'Department Name', color: 'rgba(255, 193, 7, 1)'},
    {title: 'Department Name', color: 'rgba(7, 195, 255, 1)'},
  ]