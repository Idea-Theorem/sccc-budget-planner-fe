const testnetConfig = {
  Base_URL: "http://20.151.79.66/api",
};
const mainnetConfig = {
  Base_URL: "http://localhost:5000/api",
};
// const stagingConfig = {
//   Base_URL: "https://office-management-4c6782fe80e7.herokuapp.com",
// };

const defaultConfig = testnetConfig;

export default defaultConfig;