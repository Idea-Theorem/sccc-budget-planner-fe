import { lightTheme } from "./palette";

export { lightTheme };
